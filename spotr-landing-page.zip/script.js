const form = document.getElementById("interestForm");
const emailInput = document.getElementById("email");
const message = document.getElementById("message");

form.addEventListener("submit", function (event) {
  event.preventDefault();

  const email = emailInput.value.trim();

  if (!email) {
    message.textContent = "Please enter a valid email address.";
    return;
  }

  // DEMO MODE:
  // This currently stores interest only in the visitor's browser.
  // Replace this block later with Formspree, Google Forms, Supabase,
  // Firebase, or another database/form service.

  const signups = JSON.parse(localStorage.getItem("spotrInterest") || "[]");

  if (!signups.includes(email)) {
    signups.push(email);
    localStorage.setItem("spotrInterest", JSON.stringify(signups));
  }

  message.textContent = "You're on the list. Thanks for your interest in SPOTR.";
  form.reset();
});
