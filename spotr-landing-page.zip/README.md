# SPOTR Landing Page

A simple one-page landing page for testing interest in SPOTR.

## What it includes

- Short explanation of SPOTR
- Email interest field
- Mobile-responsive design
- Ready for GitHub Pages
- Demo email storage using browser localStorage

## Important

The current version does NOT send emails to you. It stores submitted emails only in the visitor's own browser.

For a real interest test, connect the form to one of these:

- Formspree
- Google Forms
- Supabase
- Firebase
- Netlify Forms

## Publish with GitHub Pages

1. Create a new GitHub repository named `spotr-landing-page`.
2. Upload:
   - `index.html`
   - `styles.css`
   - `script.js`
3. Commit the files.
4. Go to:
   Settings → Pages
5. Under "Build and deployment":
   - Source: Deploy from a branch
   - Branch: `main`
   - Folder: `/root`
6. Save.
7. GitHub will generate a public URL similar to:
   `https://YOUR-USERNAME.github.io/spotr-landing-page/`

## Best next step

Connect the form to Formspree or Google Forms so every email submission is stored in one place.
